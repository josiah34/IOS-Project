# IOS-Project (Goal Getter)


Features Include
- Adding task 
- Deleting Task 
- Editing Task 
- Due Date For Task 
- Priortizing Task(High , Medium , Low)

![mobile-assignment](https://user-images.githubusercontent.com/25124463/227086411-22d5853f-67ff-470e-84c5-aad0a5f638d9.gif)

[Resource Used](https://www.youtube.com/watch?v=wEf1YS4vyW8&list=PLwvDm4VfkdpheGqemblOIA7v3oq0MS30i)

